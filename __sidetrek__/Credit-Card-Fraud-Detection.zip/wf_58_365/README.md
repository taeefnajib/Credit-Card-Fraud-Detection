# **Credit Card Fraud Detection**

In this project we used a dataset from [Kaggle](https://www.kaggle.com/datasets/dhanushnarayananr/credit-card-fraud) and used RandomForest algorithm to detect whether a transaction is fraudulent or not.
